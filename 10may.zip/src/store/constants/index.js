// define constants for application like
// const USER_LOGGED_SUCCESS="user login success"
// const USER_LOGGED_FAILED="user login failed"
// const USER_LOGGED_PENDING="user login failed"