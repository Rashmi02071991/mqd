import React from 'react'
import ReactDOM from 'react-dom'
import './assets/style.css'

/*
@ importing store from './store/index.js'
*/

import Main from './store/'

ReactDOM.render(<Main/>,document.getElementById("root"))