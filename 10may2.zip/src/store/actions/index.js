// write actions here for app
// ex. export function functionName(){return {type:"",...text}}