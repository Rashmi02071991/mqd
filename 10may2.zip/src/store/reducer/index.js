const reducer=(state={},action={}) => {
	return state
}

export default reducer